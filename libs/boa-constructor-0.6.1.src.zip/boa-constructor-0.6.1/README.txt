- Boa Constructor -

Thanks for checking out Boa Constructor.

Boa aims to be a simple Delphi for wxPython.
It is an IDE for Python development including visual wxPython frame
design, object browsers, documentation generation, debugging,
source control (CVS, SVN) and much more.
The Boa IDE also integrates with other Python technologies like 
Distutils, Zope, PyChecker, BicycleRepairMain.

If you are new to Boa and wxPython, work through the Getting Started Guide
and Tutorial.

Look at Changes.txt for the latest improvements.
Look at Bugs.txt for info about problems & bugs.

P.S. The short name is Boa, *not* BOA. 
Boa is not an acronymn, it's the name of a huge Python ;)

Licence:
GPL

Version:
0.6.1 - Beta
Requires wxPython 2.6 or higher, Python 2.3/2.4/2.5


Copyright:
Riaan Booysen 1999 - 2007
riaan@e.co.za


Release history:

2007-07-05 - Boa Constructor 0.6.1 beta

2005-07-11 - Boa Constructor 0.4.4

2005-03-17 - Boa Constructor 0.4.0

2004-08-25 - Boa Constructor 0.3.1

2004-08-17 - Boa Constructor 0.3.0

2003-04-01 - Boa Constructor 0.2.3

2003-01-13 - Boa Constructor 0.2.0

2002-01-28 - Boa Constructor 0.1.0 alpha

2001-03-29 - Boa Constructor 0.0.5

2000-08-30 - Boa Constructor 0.0.4

2000-02-29 - Boa Constructor 0.0.3

1999-12-25 - Pygasm 0.0.1 & 0.0.2
