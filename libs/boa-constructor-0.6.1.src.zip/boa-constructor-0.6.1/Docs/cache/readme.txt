This directory is used by the wxHtmlHelpController classes as a cache to store the help indexes.

Please note that you may also define a 'docs-cache' directory in your resource config
directory which will take precedence over this cache directory if it exists.
This is useful if you don't have rights to write to the Boa install directory.