version = '0.6.1'
wx_version = (2, 6, 0, 0)
wx_version_max = None # set to None to have no upper version check
