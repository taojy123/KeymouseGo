## Script (Python) "items"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=items
##
return [container.metatypes(), container.objectids()]
