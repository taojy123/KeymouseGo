## Script (Python) "metatype"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=metatype
##
return context.aq_parent.meta_type
