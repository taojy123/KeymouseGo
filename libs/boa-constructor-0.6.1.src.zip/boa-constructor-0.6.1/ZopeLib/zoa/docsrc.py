## Script (Python) "docsrc"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=docsrc
##
return context.aq_parent.document_src()
