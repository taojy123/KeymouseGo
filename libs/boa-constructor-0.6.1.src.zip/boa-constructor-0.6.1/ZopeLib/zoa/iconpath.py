## Script (Python) "iconpath"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=iconpath
##
return context.aq_parent.icon
