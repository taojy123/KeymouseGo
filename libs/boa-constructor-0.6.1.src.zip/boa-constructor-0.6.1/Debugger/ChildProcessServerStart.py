from ChildProcessServer import main
main()
