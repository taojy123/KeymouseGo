import wx

class ExampleStaticText(wx.StaticText):
    pass
