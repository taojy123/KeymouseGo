#-----------------------------------------------------------------------------
# Name:        prefs.plug-ins.rc.py
# Purpose:     A module for storing Plug-in file preferences
#
# Created:     2003
# RCS-ID:      $Id: prefs.plug-ins.rc.py,v 1.2 2005/05/18 13:34:46 riaan Exp $
#-----------------------------------------------------------------------------

""" A module for storing Plug-in file preferences """

import wx

